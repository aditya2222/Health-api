//== Class definition
var jVectorMap = function() {

    //== Private functions

    var demo1 = function() {
    }

    return {
        // public functions
        init: function() {
            // default charts
            demo1();
        }
    };
}();

jQuery(document).ready(function() {
    jVectorMap.init();
});